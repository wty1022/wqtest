/*
 * TestChm.java
 * 10th of June 2008
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.chm4j.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.chm4j.ChmEntry;
import org.chm4j.ChmFile;

/**
 * This is a very simple tool to extract the entries of a CHM file. 
 * It also is used as a test driver for the chm4j API.
 * @author Yann D'Isanto
 */
public class TestChm {

    /**
     * Application start method
     * @param args command line arguments
     */
    public static void main(String... args) {
        if (args.length < 1 || args.length > 2) {
            System.out.println("use : chm4j file [output-dir]");
            System.exit(0);
        }
        try {
            ChmFile cFile = new ChmFile(args[0]);
            String dir = args.length == 2 ? args[1] : ".";
            ChmEntry.Attribute attributes = ChmEntry.Attribute.ALL;
            ChmEntry[] entries = cFile.entries(attributes);
            for (ChmEntry entry : entries) {
                listChmEntry(dir, entry, attributes);
            }
        } catch (IOException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
    }

    /**
     * Extracts recursively the sub entries of the specified ChmEntry into the 
     * specified output directory according to the specified attributes.
     * @param output The output directory.
     * @param entry 
     * @param attributes
     * @throws java.io.IOException If an I/O error occurs.
     */
    private static void listChmEntry(String output, ChmEntry entry, ChmEntry.Attribute attributes) throws IOException {
        printEntry(entry);
        File dest = new File(output, entry.getPath());
        if (entry.hasAttribute(ChmEntry.Attribute.DIRECTORY)) {
            if (!dest.isDirectory()) {
                if (!dest.mkdirs()) {
                    throw new IOException("failed to create directory : " + dest);
                }
            }
            for (ChmEntry e : entry.entries(attributes)) {
                listChmEntry(output, e, attributes);
            }
        } else {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = entry.getInputStream();
                out = new FileOutputStream(dest);
                int bufferSize = 1024;
                byte[] data = new byte[bufferSize];
                int nbRead;
                while ((nbRead = in.read(data)) > 0) {
                    out.write(data, 0, nbRead);
                    out.flush();
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            } finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                } finally {
                    if (in != null) {
                        in.close();
                    }
                }
            }
        }
    }

    /**
     * Display the specified entry.
     * @param entry
     */
    private static void printEntry(ChmEntry entry) {
        StringBuilder sb = new StringBuilder("Extract entry " + entry + "(");
        boolean first = true;
        for (ChmEntry.Attribute attribute : entry.getAttributes()) {
            if (first) {
                first = false;
            } else {
                sb.append(", ");
            }
            sb.append(attribute);
        }
        sb.append(")");
        System.out.println(sb.toString());
    }
}
